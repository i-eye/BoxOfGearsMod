
#Changelog

# 1.0.0
Seeker of the FPS DLC
Adds Box of Gears Item that works correctly and as intended, and also has a model.