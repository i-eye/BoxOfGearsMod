# Item
Box of Gears is an item that is perfect in every way. It follows the design prenciples of SOTS. It is pay to win in a sense. In the meaning that the more hardware you buy the more benefit you shall receive.

































# Actual Stats
Each stack of the box will increase your move speed, attack speed, damage, jump count, regen, and armor by an amount that scales with your fps(FPS/30).

# Bugs
If you change your fps cap while in posession of item weird stuff will happen and you'll have to start a new run. Following proudly in the footsteps of the SOTS patch.

